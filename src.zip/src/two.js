import React from 'react'

export default function Two() {
  return (
    <div>

<h3>The Web Devoloper Bootcamp 2024</h3>

<div className='update1'>Updated <span className='para1'> March 2024</span></div> 

<div className='hour1'> 26 total . hoursAll . LevelsSubtitles</div>

<p className='horse1'>10 Hours of React just added. Become a Developer With ONE course - HTML, CSS, JavaScript, React, Node, MongoDB and More!</p>

<div className='dog1'><i class="fa-solid fa-check"></i>    <span className='pp11'>The ins and outs of HTML5, CSS3, and Modern JavaScript for 2021</span></div>


<div className='monkey1'><i class="fa-solid fa-check"></i> <span className='pp22'>Make REAL web applications using cutting-edge technologies</span></div>


<div className='man1'><i class="fa-solid fa-check"></i><span className='pp33'>Create responsive, accessible, and beautiful layouts</span></div>


<button className='pp44'>Add to cart</button>





    </div>
  )
}
