import React from 'react'

export default function Teach() {
  return (
    <div>
        <pre className='gowda'>
        Turn what you know into an <br></br>
         opportunity and reach <br></br>
        millions around the world.<br></br>
        </pre>
        <br></br>
        <button className='learn'>Learn More</button>
    </div>
  )
}
