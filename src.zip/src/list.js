import React from 'react'

export default function List() {
  return (
    <div>


        <a href='#'>Plans & Pricing</a><br></br>
        <a href='#'>Udemy Business</a><br></br>
        <a href='#'>Teach on udemy</a><br></br>
        <a href='#'>Login</a><br></br>
        <a href='#'>Sign Up</a><br></br>
    </div>
  )
}
