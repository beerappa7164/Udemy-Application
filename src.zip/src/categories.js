import React from 'react'

export default function Categories() {
  return (
    <div className='anchor'> 
        <a href='#'>Development</a><br></br>
        <a href='#'>Business</a><br></br>
        <a href='#'>Finance & Accounting</a><br></br>
        <a href='#'>IT and Software</a><br></br>
        <a href='#'>Office Productivity</a><br></br>
        <a href='#'>Personal development</a><br></br>
        <a href='#'>Design</a><br></br>
        <a href='#'>Marketing</a><br></br>
        <a href='#'>Lifestyle</a><br></br>
        <a href='#'>Photography & video</a><br></br>
        <a href='#'>Health & fitness</a><br></br>
        <a href='#'>Music</a><br></br>
        <a href='#'>Teaching & academics</a><br></br>

    </div>
  )
}
