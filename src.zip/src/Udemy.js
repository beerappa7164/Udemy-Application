import React from 'react'

export default function Udemy() {
  return (
    <div>
        <pre className='patil'>
            Get your team access to <br></br>
             over 25,000 top Udemy <br></br>
              courses, anytime, <br></br>
                 anywhere.
        </pre>
        <br></br>

        <button className='try'>Try udemy Business</button>

    </div>
  )
}
