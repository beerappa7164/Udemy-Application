import React from 'react'

export default function Cart() {
  return (
    <div>
        <p className='c1'>Your cart is empty.</p>
        <p className='c2'>Keep shoping</p>

    </div>
  )
}
